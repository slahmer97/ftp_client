//
// Created by slahmer on 1/6/20.
//

#ifndef FTP_CLIENT_GLOB_H
#define FTP_CLIENT_GLOB_H
int _debug_ = 0;
#endif //FTP_CLIENT_GLOB_H
